import React,{useEffect, useState} from 'react';
import { Button, Modal } from 'react-bootstrap';
import { useProvideAuth } from './Api.js';
import '../style/Login.css';

export default function Login(){
    const [values, setValues] = useState({
        email: "",
        password: ""
    });
 const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);


    const{authUser,userLogin} = useProvideAuth()


    function handleSubmit(e){
        e.preventDefault();
        userLogin(values)
       /* axios
            .post("https://jobs-api.squareboat.info/api/v1/auth/login", {
                email: values.email,
                password: values.pass,
            })
            .then((res) => {
                localStorage.setItem("token", res.data.token);
            })
            .catch((err) => console.error(err)); */
            
    }; 


    return(
    <>
    <button onClick={handleShow}
>open me</button>
    <div className='Modal-container'>
    <Modal show={show} onHide={handleClose}>
    <Modal.Header className='Modal-heading'>Login</Modal.Header>
    <Modal.Body className='Modal-body'>
    Email address <input type="email" placeholder='Enter your email' onChange={(e) => setValues({ ...values, email: e.target.value })}/> <br/><br/>
    Password <input type="password" placeholder='Enter your password' onChange={(e) => setValues({ ...values, password: e.target.value })}/> <br/><br/>
    </Modal.Body>
    <Modal.Footer className='Modal-foot'>
    <button onClick={handleSubmit}>Login</button> 
    </Modal.Footer> 
    </Modal>
    </div>
    </>
    )
}